import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pays Information',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<dynamic> countries = [];

  // Fonction pour récupérer les données des pays depuis GeoDB Cities API
  Future<void> fetchCountries() async {
    final response = await http.get(
      Uri.parse('https://wft-geo-db.p.rapidapi.com/v1/geo/countries'),
      headers: {
        'X-RapidAPI-Key': 'YOUR_API_KEY', // Remplacez par votre propre clé d'API
        'X-RapidAPI-Host': 'wft-geo-db.p.rapidapi.com',
      },
    );

    if (response.statusCode == 200) {
      setState(() {
        countries = json.decode(response.body)['data'];
      });
    } else {
      throw Exception('Échec du chargement des pays');
    }
  }

  @override
  void initState() {
    super.initState();
    fetchCountries(); // Charger les pays dès que l'application démarre
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Informations sur les Pays"),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text(
                'Menu',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              title: Text('Accueil'),
              onTap: () {
                Navigator.pop(context); // Fermer le menu
              },
            ),
            ListTile(
              title: Text('Favoris'),
              onTap: () {
                // Gérer la navigation vers les favoris
              },
            ),
            ListTile(
              title: Text('À propos'),
              onTap: () {
                // Gérer la navigation vers l'écran À propos
              },
            ),
          ],
        ),
      ),
      body: countries.isEmpty
          ? Center(child: CircularProgressIndicator()) // Afficher un loader pendant le chargement
          : ListView.builder(
              itemCount: countries.length,
              itemBuilder: (context, index) {
                final country = countries[index];
                final countryName = country['countryName'] ?? 'No Name';
                final countryCode = country['countryCode'] ?? 'N/A';
                final countryFlag = 'https://www.countryflags.io/$countryCode/flat/64.png'; // URL pour afficher le drapeau

                return Card(
                  margin: EdgeInsets.all(10),
                  child: ListTile(
                    onTap: () {
                      // Naviguer vers la page de détails du pays
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => CountryDetailScreen(country: country),
                        ),
                      );
                    },
                    leading: Image.network(
                      countryFlag,
                      width: 50,
                      height: 30,
                      fit: BoxFit.cover,
                    ),
                    title: Text(
                      countryName,
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class CountryDetailScreen extends StatelessWidget {
  final dynamic country;

  CountryDetailScreen({required this.country});

  @override
  Widget build(BuildContext context) {
    final countryName = country['countryName'] ?? 'No Name';
    final countryFlag = 'https://www.countryflags.io/${country['countryCode']}/flat/64.png';
    final countryCode = country['countryCode'] ?? 'Non disponible';
    final region = country['region'] ?? 'Non disponible';
    final population = country['population'] ?? 'Non disponible';

    return Scaffold(
      appBar: AppBar(
        title: Text('$countryName - Détails'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Image.network(
              countryFlag,
              height: 200,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 20),
            Text(
              countryName,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text('Code pays: $countryCode', style: TextStyle(fontSize: 18)),
            SizedBox(height: 10),
            Text('Région: $region', style: TextStyle(fontSize: 18)),
            SizedBox(height: 10),
            Text('Population: $population', style: TextStyle(fontSize: 18)),
          ],
        ),
      ),
    );
  }
}
